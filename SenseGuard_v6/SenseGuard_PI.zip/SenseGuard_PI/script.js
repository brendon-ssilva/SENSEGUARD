/* ── GSAP Entrance Animations ── */
// GSAP é opcional: o login continua funcional mesmo se a biblioteca de animação falhar.
const motion = window.gsap || {
  timeline: () => ({ from() { return this; }, to() { return this; } }),
  from() {},
  to() {},
  set() {},
};
const tl = motion.timeline({ defaults: { ease: "power3.out" } });

// Card flies in from the right
tl.from("#login_card", { x: 48, opacity: 0, duration: 0.8 })
  // Left panel — stagger from below
  .from("#brand_container", { y: 24, opacity: 0, duration: 0.6 }, "-=.5")
  .from("#hero_eyebrow", { y: 16, opacity: 0, duration: 0.5 }, "-=.4")
  .from("#hero_headline", { y: 20, opacity: 0, duration: 0.6 }, "-=.35")
  .from("#hero_subline", { y: 16, opacity: 0, duration: 0.5 }, "-=.4")
  .from(
    ".feature-item",
    { y: 14, opacity: 0, duration: 0.45, stagger: 0.1 },
    "-=.35",
  )
  .from("#statistics_container", { y: 18, opacity: 0, duration: 0.55 }, "-=.2")
  .from(
    "#system_status_container",
    { y: 10, opacity: 0, duration: 0.4 },
    "-=.3",
  );

// Orb slow float
motion.to("#background_orb", {
  y: -40,
  x: 20,
  duration: 6,
  repeat: -1,
  yoyo: true,
  ease: "sine.inOut",
});

/* ── Animated Stat Counters ── */
document.querySelectorAll(".statistic-value").forEach((el) => {
  const target = Number.parseFloat(el.dataset.target);
  const suffix = el.dataset.suffix || "";
  if (!Number.isFinite(target)) return;
  const decimals = String(target).includes(".") ? 1 : 0;

  motion.from(
    { val: 0 },
    {
      val: target,
      duration: 1.4,
      delay: 1.2,
      ease: "power2.out",
      onUpdate() {
        el.textContent = this.targets()[0].val.toFixed(decimals) + suffix;
      },
    },
  );
});

/* ── Card Subtle Mouse Parallax ── */
const loginCard = document.getElementById("login_card");
const loginPanel = document.querySelector(".login-panel");
if (loginPanel && loginCard) loginPanel.addEventListener("mousemove", (e) => {
  const rect = e.currentTarget.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const dx = (e.clientX - cx) / rect.width;
  const dy = (e.clientY - cy) / rect.height;
  motion.to(loginCard, {
    rotateY: dx * 4,
    rotateX: -dy * 4,
    duration: 0.6,
    ease: "power2.out",
    transformPerspective: 900,
  });
});

if (loginPanel && loginCard) loginPanel.addEventListener("mouseleave", () => {
  motion.to(loginCard, {
    rotateY: 0,
    rotateX: 0,
    duration: 0.8,
    ease: "elastic.out(1,.6)",
  });
});

/* ── Toggle Password Visibility ── */
const pwInput = document.getElementById("password_input");
const togglePwBtn = document.getElementById("password_toggle_button");
const eyeIcon = document.getElementById("eye_icon");

const eyeOpen = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.8"/>`;
const eyeOff = `<path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>`;

if (togglePwBtn && pwInput && eyeIcon) togglePwBtn.addEventListener("click", () => {
  const visible = pwInput.type === "text";
  pwInput.type = visible ? "password" : "text";
  eyeIcon.innerHTML = visible ? eyeOpen : eyeOff;
  motion.from(eyeIcon, {
    scale: 0.7,
    opacity: 0,
    duration: 0.2,
    ease: "back.out(2)",
  });
});

/* ── Role Quick-Fill ── */
document.querySelectorAll(".role-button").forEach((btn) => {
  btn.addEventListener("click", () => {
    const emailInput = document.getElementById("email_input");
    if (!emailInput || !btn.dataset.email) return;
    emailInput.value = btn.dataset.email;
    motion.from(emailInput, {
      scale: 0.97,
      duration: 0.25,
      ease: "back.out(2)",
    });
  });
});

/* ── Form Submission ── */
const loginForm = document.getElementById("login_form");
const submitBtn = document.getElementById("submit_button");
const errorContainer = document.getElementById("error_message_container");
const errorText = document.getElementById("error_text");

function showError(msg) {
  if (!errorText || !errorContainer) return;
  errorText.textContent = msg;
  errorContainer.classList.add("show");
  motion.from(errorContainer, {
    y: -8,
    opacity: 0,
    duration: 0.3,
    ease: "power2.out",
  });
  motion.to(loginCard, {
    x: -6,
    duration: 0.06,
    repeat: 5,
    yoyo: true,
    ease: "none",
    onComplete() {
      motion.set(loginCard, { x: 0 });
    },
  });
}

function hideError() {
  if (errorContainer) errorContainer.classList.remove("show");
}

function setLoading(on) {
  if (!submitBtn) return;
  submitBtn.disabled = on;
  submitBtn.classList.toggle("loading", on);
  const label = submitBtn.querySelector(".submit-label");
  if (label) label.textContent = on ? "Autenticando…" : "Entrar";
}

/* Ripple on Button Click */
if (submitBtn) submitBtn.addEventListener("click", function (e) {
  const rect = this.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height);
  const r = document.createElement("span");
  r.className = "ripple";
  r.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - rect.left - size / 2}px;top:${e.clientY - rect.top - size / 2}px`;
  this.appendChild(r);
  r.addEventListener("animationend", () => r.remove());
});

if (loginForm) loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideError();

  const emailInput = document.getElementById("email_input");
  if (!emailInput || !pwInput || !submitBtn) {
    showError("O formulário de login não foi carregado corretamente. Atualize a página.");
    return;
  }
  const emailVal = emailInput.value.trim();
  const pwVal = pwInput.value;

  if (!emailVal || !pwVal) {
    showError("Informe o e-mail e a senha.");
    return;
  }

  setLoading(true);

  try {
    const response = await fetch("login.php", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify({ email: emailVal, password: pwVal }),
    });

    if (!response.ok) {
      // Não revelar detalhes internos do servidor na interface.
      throw new Error("Falha na autenticação.");
    }

    let data;
    try {
      data = await response.json();
    } catch {
      throw new Error("Resposta inválida do servidor. Tente novamente mais tarde.");
    }

    if (!data || data.success !== true) {
      showError("E-mail ou senha inválidos, ou não foi possível entrar.");
    } else {
      // O destino deve ser definido pelo servidor e validado no backend.
      const redirect = typeof data.redirect === "string" ? data.redirect : "";
      let safeRedirect = "dashboard.html";
      if (redirect) {
        try {
          const targetUrl = new URL(redirect, window.location.href);
          // Só permite redirecionamento para a mesma origem.
          if (targetUrl.origin === window.location.origin) {
            safeRedirect = targetUrl.href;
          }
        } catch {
          // Mantém o destino local padrão se a URL for inválida.
        }
      }
      window.location.href = safeRedirect;
    }
  } catch {
    showError("Não foi possível entrar. Verifique sua conexão e tente novamente.");
  } finally {
    setLoading(false);
  }
});