# SenseGuard — versão refatorada para o Projeto Integrador

Sistema WEB de gestão de manutenção industrial, com autenticação por sessão e CRUD de máquinas, sensores, ordens de serviço e usuários.

## 1. Requisitos

- XAMPP com Apache e MySQL/MariaDB ativos.
- PHP 8.1 ou superior, com extensões `PDO` e `pdo_mysql` habilitadas.
- Navegador moderno com JavaScript habilitado.

## 2. Instalação local no XAMPP

1. Copie a pasta `SenseGuard_PI` para `C:\xampp\htdocs\` e renomeie para `SENSEGUARD` (ou ajuste os caminhos conforme sua instalação).
2. Abra o phpMyAdmin e importe `schema.sql` em um banco novo. O script cria o banco `senseguard`, as tabelas e os registros de referência.
3. Execute `usuario_teste.sql` depois de `schema.sql`.
4. Confira `config.local.php`. A configuração entregue corresponde ao XAMPP local padrão (`127.0.0.1`, banco `senseguard`, usuário `root` e senha vazia). Em outro ambiente, ajuste as credenciais.
5. Acesse `http://localhost/SENSEGUARD/`.

**Credenciais de demonstração**

- E-mail: `admin.teste@senseguard.local`
- Senha: `SenseGuard@123`

O usuário de teste é apenas para demonstração local. Troque/remova essa conta antes de qualquer publicação ou implantação real.

## 3. Banco já existente

`CREATE TABLE IF NOT EXISTS` não atualiza tabelas que já existem. Portanto:

- Para uma instalação limpa, use `schema.sql`.
- Para a estrutura antiga enviada junto do projeto, faça backup e revise/executa uma única vez `migracao_atualizacao.sql`.
- A migração associa registros antigos sem organização à empresa de ID `1`. Revise essa regra se o banco possuir mais de uma empresa.
- Não execute a migração sobre um banco que já tenha a estrutura nova.

## 4. Arquivos principais

| Arquivo | Responsabilidade |
|---|---|
| `conexao.php` | Instancia o PDO compartilhado com `ERRMODE_EXCEPTION`, prepared statements nativos e `utf8mb4`. |
| `protect.php` | Inicia e valida a sessão; protege páginas privadas e revalida a conta no banco. |
| `login.php` | Valida credenciais, verifica `password_hash()` e cria a sessão. |
| `logout.php` | Encerra a sessão com validação de token CSRF. |
| `dashboard.php` | Página privada; inclui `conexao.php` e `protect.php`. |
| `api.php` | Endpoint JSON com CRUD, validação de dados, autorização, escopo por organização e transações. |
| `dashboard.js` | Interface e chamadas à API com sessão e CSRF. |
| `settings.js` | Tela de configurações, tema e preferências locais; atualização do próprio nome pela API. |
| `dashboard.css` | Estilos do painel. |
| `index.html`, `styles.css`, `script.js` | Tela de login, estilos e animações. |
| `schema.sql` | Criação do banco e das tabelas para instalação limpa. |
| `banco_de_dados.txt` | Mesmo script SQL em formato `.txt`, pronto para anexar ao Git do PI. |
| `migracao_atualizacao.sql` | Migração única para o banco da versão anterior. |
| `usuario_teste.sql` | Inserção separada do usuário de teste. |
| `.htaccess` / `.gitignore` | Bloqueio de acesso a arquivos internos e exclusão de credenciais do Git. |

`dashboard.html` é mantido apenas como endereço de compatibilidade e redireciona para `dashboard.php`, que é a página protegida.

## 5. Regras de segurança aplicadas

- Todas as páginas PHP que consultam o banco usam `require_once __DIR__ . '/conexao.php'`.
- O PDO utiliza `PDO::ERRMODE_EXCEPTION`, `PDO::ATTR_EMULATE_PREPARES => false` e DSN com `charset=utf8mb4`.
- Valores externos são enviados por `prepare()` / `execute()` com marcadores posicionais `?`. Identificadores SQL dinâmicos vêm exclusivamente de mapas fixos no servidor.
- As gravações que envolvem a tabela `maquina` e a vinculação de sensores são executadas em transação.
- A API exige sessão autenticada e token CSRF nas operações de escrita. Os cookies de sessão usam `HttpOnly`, `SameSite=Lax`, nome próprio e caminho limitado à pasta do sistema.
- O perfil e o status do usuário são revalidados no banco em cada requisição protegida.
- As consultas de CRUD são limitadas à organização vinculada à sessão. A API valida se máquinas, sensores, ordens e responsáveis pertencem à mesma organização; as chaves estrangeiras compostas também reforçam esses vínculos no banco.
- Mensagens técnicas são enviadas a `error_log`; a interface recebe mensagens genéricas ou de validação.
- Exclusões são restringidas quando existem registros históricos/relacionados, evitando apagar ordens e medições em cascata.
- `config.local.php` está no `.gitignore`. No Git, mantenha apenas `config.local.php.example`; nunca publique credenciais reais.

## 6. Configurações do usuário

A tela de Configurações está integrada ao menu lateral do painel. O nome do usuário é atualizado no servidor por `PUT api.php?entity=me`, com sessão e CSRF. A preferência de tema (claro, escuro ou sistema) e a opção de notificações por e-mail são armazenadas no navegador; a opção de notificações ainda não aciona um serviço de envio. Os botões de alteração de e-mail e senha abrem um aviso de segurança; a efetivação dessas mudanças exige um fluxo 2FA no backend, que ainda não faz parte desta entrega.

## 7. Observações de implantação

A configuração `root` sem senha é adequada somente ao XAMPP local de sala de aula. Em produção, use usuário MySQL exclusivo, senha forte, HTTPS, configuração fora da raiz pública, política de backup e logs monitorados. O limite de tentativas do login é armazenado na sessão e não substitui rate limiting centralizado por IP/conta em produção.

O painel utiliza GSAP por CDN para animações. Sem acesso à CDN, as funções de CRUD continuam funcionando, mas animações GSAP podem não ser executadas.
