<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');

function responderLogout(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

require_once __DIR__ . '/protect.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    responderLogout(405, ['success' => false, 'message' => 'Método não permitido.']);
}

try {
    iniciarSessaoSegura();

    $csrfSession = $_SESSION['csrf_token'] ?? '';
    $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($csrfSession) || $csrfSession === '' || !is_string($csrfHeader) || !hash_equals($csrfSession, $csrfHeader)) {
        responderLogout(403, ['success' => false, 'message' => 'Requisição não autorizada. Atualize a página e tente novamente.']);
    }

    destruirSessaoSegura();

    responderLogout(200, ['success' => true, 'message' => 'Sessão encerrada com sucesso.']);
} catch (Throwable $e) {
    error_log('SenseGuard logout: erro ao encerrar sessão: ' . $e->getMessage());
    responderLogout(500, ['success' => false, 'message' => 'Não foi possível encerrar a sessão.']);
}
