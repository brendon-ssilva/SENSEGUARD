<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Vary: Cookie');

function responder(int $status, array $payload): never
{
    http_response_code($status);
    try {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        http_response_code(500);
        echo '{"error":"Erro interno."}';
    }
    exit;
}

final class ApiException extends RuntimeException
{
    public function __construct(public readonly int $httpStatus, string $message)
    {
        parent::__construct($message);
    }
}

try {
    require_once __DIR__ . '/conexao.php';
    require_once __DIR__ . '/protect.php';
} catch (Throwable $e) {
    error_log('SenseGuard API: falha ao carregar a conexão: ' . $e->getMessage());
    responder(500, ['error' => 'Não foi possível conectar ao banco de dados.']);
}

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if (!in_array($method, ['GET', 'POST', 'PUT', 'DELETE'], true)) {
    header('Allow: GET, POST, PUT, DELETE');
    responder(405, ['error' => 'Método não permitido.']);
}

try {
    $usuarioLogado = obterUsuarioAutenticado($pdo);
    if ($usuarioLogado === null) {
        responder(401, ['error' => 'Sua sessão expirou. Entre novamente.']);
    }

    if (in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
        $csrfSession = $_SESSION['csrf_token'] ?? '';
        $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!is_string($csrfSession) || $csrfSession === '' || !is_string($csrfHeader) || !hash_equals($csrfSession, $csrfHeader)) {
            responder(403, ['error' => 'Requisição não autorizada. Atualize a página e tente novamente.']);
        }
    }

    $corporationId = (int) $usuarioLogado['id_corporacao'];
    $userId = (int) $usuarioLogado['id_usuario'];
    $role = strtolower(trim((string) $usuarioLogado['role']));
    $isAdmin = $role === 'admin';
    $canWrite = in_array($role, ['admin', 'supervisor'], true);

    $entity = $_GET['entity'] ?? '';
    if (!is_string($entity) || $entity === '') {
        responder(400, ['error' => 'Entidade não informada.']);
    }

    $map = [
        'corporations' => ['table' => 'corporacao', 'pk' => 'id_corporacao'],
        'users' => ['table' => 'usuario', 'pk' => 'id_usuario'],
        'machines' => ['table' => 'maquina', 'pk' => 'id_maquina'],
        'sensors' => ['table' => 'sensor', 'pk' => 'id_sensor'],
        'orders' => ['table' => 'ordem_servico', 'pk' => 'id_os'],
    ];

    $selectColumns = [
        'corporations' => 'id_corporacao, nome, cnpj, email',
        'users' => 'id_usuario, nome, email, telefone, role, status, data_criacao, id_permissao, id_corporacao',
        'machines' => 'id_maquina, nome, modelo, fabricante, localizacao, departamento, status, data_instalacao, ultima_manutencao, proxima_manutencao, id_corporacao',
        'sensors' => 'id_sensor, nome, tipo, unidade, localizacao, min_limite, max_limite, valor_atual, status, ultima_leitura, id_maquina, id_corporacao',
        'orders' => 'id_os, titulo, descricao, tipo, prioridade, status, horas_estimadas, data_prevista, data_abertura, data_encerramento, id_maquina, id_usuario, id_corporacao',
    ];

    if ($entity === 'me') {
        if ($method === 'GET') {
            responder(200, [
                'id' => (string) $usuarioLogado['id_usuario'],
                'name' => (string) $usuarioLogado['nome'],
                'email' => (string) $usuarioLogado['email'],
                'role' => $role,
            ]);
        }

        if ($method === 'PUT') {
            $profileInput = lerJson();
            if (array_diff(array_keys($profileInput), ['name']) !== [] || !array_key_exists('name', $profileInput)) {
                throw new ApiException(400, 'Envie somente o campo de nome.');
            }

            $name = $profileInput['name'];
            if (!is_string($name)) {
                throw new ApiException(400, 'Informe um nome válido.');
            }
            $name = trim($name);
            preg_match_all('/./us', $name, $nameCharacters);
            if ($name === '' || count($nameCharacters[0]) > 100 || preg_match('/[\x00-\x1F\x7F]/u', $name)) {
                throw new ApiException(422, 'O nome deve ter entre 1 e 100 caracteres válidos.');
            }

            $updateProfile = $pdo->prepare(
                'UPDATE usuario SET nome = ? WHERE id_usuario = ? AND id_corporacao = ?'
            );
            $updateProfile->execute([$name, $userId, $corporationId]);

            $profileStmt = $pdo->prepare(
                'SELECT id_usuario, nome, email, role FROM usuario WHERE id_usuario = ? AND id_corporacao = ? AND status = ? LIMIT 1'
            );
            $profileStmt->execute([$userId, $corporationId, 'ativo']);
            $updatedProfile = $profileStmt->fetch();
            if (!is_array($updatedProfile)) {
                throw new ApiException(404, 'Perfil não encontrado.');
            }

            $_SESSION['user_name'] = (string) $updatedProfile['nome'];
            responder(200, [
                'id' => (string) $updatedProfile['id_usuario'],
                'name' => (string) $updatedProfile['nome'],
                'email' => (string) $updatedProfile['email'],
                'role' => strtolower(trim((string) $updatedProfile['role'])),
            ]);
        }

        responder(405, ['error' => 'Método não permitido para o perfil.']);
    }

    if ($entity === 'all' && $method === 'GET') {
        $response = [];
        foreach ($map as $key => $info) {
            $stmt = $pdo->prepare(
                'SELECT ' . $selectColumns[$key] . ' FROM `' . $info['table'] . '` WHERE id_corporacao = ? ORDER BY `' . $info['pk'] . '` DESC'
            );
            $stmt->execute([$corporationId]);
            $rows = $stmt->fetchAll();
            $response[$key] = array_map(
                static fn(array $row): array => mapToJs($key, $row, $pdo, $corporationId, $isAdmin),
                $rows
            );
        }
        responder(200, $response);
    }

    if (!array_key_exists($entity, $map)) {
        responder(400, ['error' => 'Entidade inválida.']);
    }

    if ($entity === 'corporations' && $method !== 'GET') {
        responder(403, ['error' => 'O cadastro da organização não pode ser alterado por esta tela.']);
    }
    if ($entity === 'users' && $method !== 'GET' && !$isAdmin) {
        responder(403, ['error' => 'Somente administradores podem alterar usuários.']);
    }
    if (in_array($method, ['POST', 'PUT', 'DELETE'], true) && !$canWrite) {
        responder(403, ['error' => 'Seu perfil não possui permissão para alterar estes registros.']);
    }

    $table = $map[$entity]['table'];
    $pk = $map[$entity]['pk'];
    $idRaw = $_GET['id'] ?? null;
    $id = 0;
    if ($idRaw !== null) {
        if (!is_string($idRaw) || !ctype_digit($idRaw) || (int) $idRaw < 1) {
            responder(400, ['error' => 'Identificador inválido.']);
        }
        $id = (int) $idRaw;
    }

    $input = in_array($method, ['POST', 'PUT'], true) ? lerJson() : [];

    if ($method === 'GET') {
        if ($id > 0) {
            $stmt = $pdo->prepare("SELECT {$selectColumns[$entity]} FROM `$table` WHERE `$pk` = ? AND id_corporacao = ? LIMIT 1");
            $stmt->execute([$id, $corporationId]);
            $row = $stmt->fetch();
            if (!is_array($row)) {
                responder(404, ['error' => 'Registro não encontrado.']);
            }
            responder(200, mapToJs($entity, $row, $pdo, $corporationId, $isAdmin));
        }

        $stmt = $pdo->prepare("SELECT {$selectColumns[$entity]} FROM `$table` WHERE id_corporacao = ? ORDER BY `$pk` DESC");
        $stmt->execute([$corporationId]);
        $rows = $stmt->fetchAll();
        responder(200, array_map(
            static fn(array $row): array => mapToJs($entity, $row, $pdo, $corporationId, $isAdmin),
            $rows
        ));
    }

    if ($entity === 'corporations') {
        responder(403, ['error' => 'Operação não permitida.']);
    }

    if ($method === 'POST') {
        if ($entity === 'machines') {
            $data = buildMachineData($input, true);
            $sensorIds = validateSensorIds($input['sensorIds'] ?? []);

            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                'INSERT INTO maquina (nome, modelo, fabricante, localizacao, departamento, status, data_instalacao, ultima_manutencao, proxima_manutencao, id_corporacao)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $data['nome'], $data['modelo'], $data['fabricante'], $data['localizacao'],
                $data['departamento'], $data['status'], $data['data_instalacao'],
                $data['ultima_manutencao'], $data['proxima_manutencao'], $corporationId,
            ]);
            $newId = (int) $pdo->lastInsertId();
            syncMachineSensors($pdo, $newId, $corporationId, $sensorIds);
            $pdo->commit();
            $row = buscarRegistro($pdo, $table, $pk, $newId, $corporationId, $selectColumns[$entity]);
            responder(201, mapToJs($entity, $row, $pdo, $corporationId, $isAdmin));
        }

        if ($entity === 'users') {
            $data = buildUserData($input, true, $pdo);
            $stmt = $pdo->prepare(
                'INSERT INTO usuario (nome, email, senha, telefone, role, status, id_permissao, id_corporacao)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $data['nome'], $data['email'], $data['senha'], $data['telefone'],
                $data['role'], $data['status'], $data['id_permissao'], $corporationId,
            ]);
            $newId = (int) $pdo->lastInsertId();
            $row = buscarRegistro($pdo, $table, $pk, $newId, $corporationId, $selectColumns[$entity]);
            responder(201, mapToJs($entity, $row, $pdo, $corporationId, true));
        }

        if ($entity === 'sensors') {
            $data = buildSensorData($input, $corporationId, $pdo);
            $stmt = $pdo->prepare(
                'INSERT INTO sensor (nome, tipo, unidade, localizacao, min_limite, max_limite, valor_atual, status, ultima_leitura, id_maquina, id_corporacao)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $data['nome'], $data['tipo'], $data['unidade'], $data['localizacao'],
                $data['min_limite'], $data['max_limite'], $data['valor_atual'],
                $data['status'], $data['ultima_leitura'], $data['id_maquina'], $corporationId,
            ]);
            $newId = (int) $pdo->lastInsertId();
            $row = buscarRegistro($pdo, $table, $pk, $newId, $corporationId, $selectColumns[$entity]);
            responder(201, mapToJs($entity, $row, $pdo, $corporationId, $isAdmin));
        }

        if ($entity === 'orders') {
            $data = buildOrderData($input, $corporationId, $pdo);
            $stmt = $pdo->prepare(
                'INSERT INTO ordem_servico (titulo, descricao, tipo, prioridade, status, horas_estimadas, data_prevista, data_encerramento, id_maquina, id_usuario, id_corporacao)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $data['titulo'], $data['descricao'], $data['tipo'], $data['prioridade'],
                $data['status'], $data['horas_estimadas'], $data['data_prevista'],
                $data['data_encerramento'], $data['id_maquina'], $data['id_usuario'], $corporationId,
            ]);
            $newId = (int) $pdo->lastInsertId();
            $row = buscarRegistro($pdo, $table, $pk, $newId, $corporationId, $selectColumns[$entity]);
            responder(201, mapToJs($entity, $row, $pdo, $corporationId, $isAdmin));
        }
    }

    if ($method === 'PUT') {
        if ($id < 1) {
            responder(400, ['error' => 'ID válido é obrigatório.']);
        }
        $current = buscarRegistro($pdo, $table, $pk, $id, $corporationId, $selectColumns[$entity]);

        if ($entity === 'machines') {
            $data = buildMachineData($input, false);
            $sensorIds = array_key_exists('sensorIds', $input) ? validateSensorIds($input['sensorIds']) : null;
            $pdo->beginTransaction();
            atualizarRegistro($pdo, 'maquina', 'id_maquina', $id, $corporationId, $data);
            if ($sensorIds !== null) {
                syncMachineSensors($pdo, $id, $corporationId, $sensorIds);
            }
            $pdo->commit();
        } elseif ($entity === 'users') {
            if ($id === $userId) {
                $newRole = $input['role'] ?? $current['role'];
                $newStatus = $input['status'] ?? $current['status'];
                if ($newRole !== $current['role'] || $newStatus !== $current['status']) {
                    responder(409, ['error' => 'Não é permitido alterar o próprio perfil ou status.']);
                }
            }
            $data = buildUserData($input, false, $pdo);
            atualizarRegistro($pdo, 'usuario', 'id_usuario', $id, $corporationId, $data);
        } elseif ($entity === 'sensors') {
            $data = buildSensorData($input, $corporationId, $pdo);
            atualizarRegistro($pdo, 'sensor', 'id_sensor', $id, $corporationId, $data);
        } elseif ($entity === 'orders') {
            $data = buildOrderData($input, $corporationId, $pdo, isset($current['data_encerramento']) ? (string) $current['data_encerramento'] : null);
            atualizarRegistro($pdo, 'ordem_servico', 'id_os', $id, $corporationId, $data);
        }

        $row = buscarRegistro($pdo, $table, $pk, $id, $corporationId, $selectColumns[$entity]);
        responder(200, mapToJs($entity, $row, $pdo, $corporationId, $isAdmin));
    }

    if ($method === 'DELETE') {
        if ($id < 1) {
            responder(400, ['error' => 'ID válido é obrigatório.']);
        }
        if ($entity === 'users' && $id === $userId) {
            responder(409, ['error' => 'Não é permitido excluir o próprio usuário.']);
        }

        if ($entity === 'machines') {
            $pdo->beginTransaction();
            $clear = $pdo->prepare('UPDATE sensor SET id_maquina = NULL WHERE id_maquina = ? AND id_corporacao = ?');
            $clear->execute([$id, $corporationId]);
            $delete = $pdo->prepare('DELETE FROM maquina WHERE id_maquina = ? AND id_corporacao = ?');
            $delete->execute([$id, $corporationId]);
            if ($delete->rowCount() < 1) {
                throw new ApiException(404, 'Máquina não encontrada.');
            }
            $pdo->commit();
        } else {
            $delete = $pdo->prepare("DELETE FROM `$table` WHERE `$pk` = ? AND id_corporacao = ?");
            $delete->execute([$id, $corporationId]);
            if ($delete->rowCount() < 1) {
                responder(404, ['error' => 'Registro não encontrado.']);
            }
        }

        responder(200, ['success' => true, 'id' => (string) $id]);
    }

    responder(405, ['error' => 'Operação não permitida.']);
} catch (ApiException $e) {
    if ($pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    responder($e->httpStatus, ['error' => $e->getMessage()]);
} catch (PDOException $e) {
    if ($pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SenseGuard API: erro PDO (' . ($entity ?? 'desconhecida') . '/' . $method . '): ' . $e->getMessage());
    if ((string) $e->getCode() === '23000') {
        responder(409, ['error' => 'A operação não pode ser concluída porque há dados duplicados ou registros vinculados.']);
    }
    responder(500, ['error' => 'Não foi possível processar a operação no banco de dados.']);
} catch (Throwable $e) {
    if ($pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SenseGuard API: erro inesperado: ' . $e->getMessage());
    responder(500, ['error' => 'Ocorreu um erro interno ao processar a requisição.']);
}

/** Lê exclusivamente objetos JSON enviados em POST/PUT. */
function lerJson(): array
{
    $contentType = strtolower(trim(explode(';', (string) ($_SERVER['CONTENT_TYPE'] ?? ''))[0]));
    if ($contentType !== 'application/json') {
        throw new ApiException(415, 'Envie os dados no formato JSON.');
    }

    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 1_048_576) {
        throw new ApiException(413, 'A requisição excede o tamanho permitido.');
    }

    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        throw new ApiException(400, 'O corpo da requisição está vazio.');
    }

    try {
        $data = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        throw new ApiException(400, 'JSON inválido.');
    }

    if (!is_array($data) || array_is_list($data)) {
        throw new ApiException(400, 'Formato de dados inválido.');
    }

    return $data;
}

function rejeitarCamposDesconhecidos(array $data, array $allowed): void
{
    $unknown = array_diff(array_keys($data), $allowed);
    if ($unknown !== []) {
        throw new ApiException(400, 'A requisição contém campos não permitidos.');
    }
}

function tamanhoTexto(string $value): int
{
    if (function_exists('mb_strlen')) {
        return mb_strlen($value, 'UTF-8');
    }
    $count = preg_match_all('/./us', $value);
    return $count === false ? strlen($value) : $count;
}

function textoObrigatorio(array $data, string $key, int $max, string $label): string
{
    $value = $data[$key] ?? null;
    if (!is_string($value)) {
        throw new ApiException(400, $label . ' é obrigatório.');
    }
    $value = trim($value);
    if ($value === '' || tamanhoTexto($value) > $max) {
        throw new ApiException(400, 'Informe um valor válido para ' . $label . '.');
    }
    return $value;
}

function textoOpcional(array $data, string $key, int $max, string $label): ?string
{
    $value = $data[$key] ?? null;
    if ($value === null || $value === '') {
        return null;
    }
    if (!is_string($value)) {
        throw new ApiException(400, 'Valor inválido para ' . $label . '.');
    }
    $value = trim($value);
    if (tamanhoTexto($value) > $max) {
        throw new ApiException(400, $label . ' excede o tamanho permitido.');
    }
    return $value === '' ? null : $value;
}

function dataSql(mixed $value, string $label): ?string
{
    if ($value === null || $value === '') {
        return null;
    }
    if (!is_string($value)) {
        throw new ApiException(400, 'Data inválida: ' . $label . '.');
    }
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    $errors = DateTime::getLastErrors();
    if (!$date || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0)) || $date->format('Y-m-d') !== $value) {
        throw new ApiException(400, 'Informe uma data válida para ' . $label . '.');
    }
    return $value;
}

function dataHoraSql(mixed $value, string $label): ?string
{
    if ($value === null || $value === '') {
        return null;
    }
    if (!is_string($value)) {
        throw new ApiException(400, 'Data e hora inválidas: ' . $label . '.');
    }
    $formats = ['!Y-m-d H:i:s', '!Y-m-d\TH:i:s'];
    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $value);
        $errors = DateTime::getLastErrors();
        if ($date && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
            return $date->format('Y-m-d H:i:s');
        }
    }
    throw new ApiException(400, 'Informe uma data e hora válidas para ' . $label . '.');
}

function numeroFinito(mixed $value, string $label, float $min, float $max): float
{
    if (!is_int($value) && !is_float($value) && !(is_string($value) && is_numeric($value))) {
        throw new ApiException(400, 'Informe um número válido para ' . $label . '.');
    }
    $number = (float) $value;
    if (!is_finite($number) || $number < $min || $number > $max) {
        throw new ApiException(400, 'O valor de ' . $label . ' está fora do intervalo permitido.');
    }
    return $number;
}

function validarEnum(mixed $value, array $allowed, string $label): string
{
    if (!is_string($value) || !in_array($value, $allowed, true)) {
        throw new ApiException(400, 'Valor inválido para ' . $label . '.');
    }
    return $value;
}

function buscarRegistro(PDO $pdo, string $table, string $pk, int $id, int $corporationId, string $columns): array
{
    $stmt = $pdo->prepare("SELECT $columns FROM `$table` WHERE `$pk` = ? AND id_corporacao = ? LIMIT 1");
    $stmt->execute([$id, $corporationId]);
    $row = $stmt->fetch();
    if (!is_array($row)) {
        throw new ApiException(404, 'Registro não encontrado.');
    }
    return $row;
}

function atualizarRegistro(PDO $pdo, string $table, string $pk, int $id, int $corporationId, array $data): void
{
    if ($data === []) {
        throw new ApiException(400, 'Nenhum campo válido foi enviado.');
    }
    $sets = [];
    foreach (array_keys($data) as $column) {
        $sets[] = '`' . $column . '` = ?';
    }
    $sql = 'UPDATE `' . $table . '` SET ' . implode(', ', $sets) . ' WHERE `' . $pk . '` = ? AND id_corporacao = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge(array_values($data), [$id, $corporationId]));
}

function buildMachineData(array $input, bool $isCreate): array
{
    rejeitarCamposDesconhecidos($input, [
        'name', 'model', 'manufacturer', 'location', 'department', 'status',
        'installDate', 'lastMaintenance', 'nextMaintenance', 'sensorIds',
    ]);
    $name = textoObrigatorio($input, 'name', 100, 'nome da máquina');
    return [
        'nome' => $name,
        'modelo' => textoOpcional($input, 'model', 100, 'modelo'),
        'fabricante' => textoOpcional($input, 'manufacturer', 100, 'fabricante'),
        'localizacao' => textoOpcional($input, 'location', 100, 'localização'),
        'departamento' => textoOpcional($input, 'department', 100, 'departamento'),
        'status' => validarEnum($input['status'] ?? 'operando', ['operando', 'alerta', 'critico', 'manutencao', 'inativo'], 'status da máquina'),
        'data_instalacao' => dataSql($input['installDate'] ?? null, 'instalação'),
        'ultima_manutencao' => dataSql($input['lastMaintenance'] ?? null, 'última manutenção'),
        'proxima_manutencao' => dataSql($input['nextMaintenance'] ?? null, 'próxima manutenção'),
    ];
}

function buildSensorData(array $input, int $corporationId, PDO $pdo): array
{
    rejeitarCamposDesconhecidos($input, [
        'name', 'type', 'unit', 'location', 'currentValue', 'minThreshold',
        'maxThreshold', 'lastReadingAt', 'machineId', 'status',
    ]);

    $min = numeroFinito($input['minThreshold'] ?? 0, 'limite mínimo', -1_000_000_000, 1_000_000_000);
    $max = numeroFinito($input['maxThreshold'] ?? 100, 'limite máximo', -1_000_000_000, 1_000_000_000);
    if ($min > $max) {
        throw new ApiException(400, 'O limite mínimo não pode ser maior que o limite máximo.');
    }

    $machineId = $input['machineId'] ?? null;
    if ($machineId === '') {
        $machineId = null;
    }
    if ($machineId !== null) {
        $machineId = validarId($machineId, 'máquina');
        $check = $pdo->prepare('SELECT COUNT(*) FROM maquina WHERE id_maquina = ? AND id_corporacao = ?');
        $check->execute([$machineId, $corporationId]);
        if ((int) $check->fetchColumn() !== 1) {
            throw new ApiException(400, 'A máquina selecionada não pertence à organização atual.');
        }
    }

    return [
        'nome' => textoObrigatorio($input, 'name', 50, 'nome do sensor'),
        'tipo' => validarEnum($input['type'] ?? null, ['temperatura', 'vibracao', 'pressao', 'corrente', 'umidade', 'rpm'], 'tipo de sensor'),
        'unidade' => textoOpcional($input, 'unit', 20, 'unidade'),
        'localizacao' => textoOpcional($input, 'location', 100, 'localização'),
        'min_limite' => $min,
        'max_limite' => $max,
        'valor_atual' => numeroFinito($input['currentValue'] ?? 0, 'leitura atual', -1_000_000_000, 1_000_000_000),
        'status' => validarEnum($input['status'] ?? 'online', ['online', 'offline', 'alerta'], 'status do sensor'),
        'ultima_leitura' => dataHoraSql($input['lastReadingAt'] ?? null, 'última leitura'),
        'id_maquina' => $machineId,
    ];
}

function buildOrderData(array $input, int $corporationId, PDO $pdo, ?string $previousCompletedAt = null): array
{
    rejeitarCamposDesconhecidos($input, [
        'title', 'description', 'type', 'priority', 'status', 'estimatedHours',
        'scheduledFor', 'assignedToId', 'machineId', 'completedAt',
    ]);

    $machineId = validarId($input['machineId'] ?? null, 'máquina');
    $assignedToId = validarId($input['assignedToId'] ?? null, 'responsável');

    $machineCheck = $pdo->prepare('SELECT COUNT(*) FROM maquina WHERE id_maquina = ? AND id_corporacao = ?');
    $machineCheck->execute([$machineId, $corporationId]);
    if ((int) $machineCheck->fetchColumn() !== 1) {
        throw new ApiException(400, 'A máquina selecionada não pertence à organização atual.');
    }

    $userCheck = $pdo->prepare('SELECT COUNT(*) FROM usuario WHERE id_usuario = ? AND id_corporacao = ? AND status = ?');
    $userCheck->execute([$assignedToId, $corporationId, 'ativo']);
    if ((int) $userCheck->fetchColumn() !== 1) {
        throw new ApiException(400, 'O responsável selecionado não existe ou está inativo.');
    }

    $status = validarEnum($input['status'] ?? 'aberta', ['aberta', 'em_andamento', 'concluida', 'cancelada'], 'status da ordem');
    $completedAt = null;
    if ($status === 'concluida') {
        $completedAt = $previousCompletedAt !== null && $previousCompletedAt !== ''
            ? $previousCompletedAt
            : date('Y-m-d H:i:s');
    }

    return [
        'titulo' => textoObrigatorio($input, 'title', 150, 'título da ordem'),
        'descricao' => textoOpcional($input, 'description', 15000, 'descrição'),
        'tipo' => validarEnum($input['type'] ?? 'preventiva', ['preventiva', 'preditiva', 'corretiva'], 'tipo de manutenção'),
        'prioridade' => validarEnum($input['priority'] ?? 'baixa', ['baixa', 'media', 'alta', 'critica'], 'prioridade'),
        'status' => $status,
        'horas_estimadas' => numeroFinito($input['estimatedHours'] ?? 2, 'horas estimadas', 0, 100000),
        'data_prevista' => dataSql($input['scheduledFor'] ?? null, 'data prevista'),
        'data_encerramento' => $completedAt,
        'id_maquina' => $machineId,
        'id_usuario' => $assignedToId,
    ];
}

function buildUserData(array $input, bool $isCreate, PDO $pdo): array
{
    rejeitarCamposDesconhecidos($input, ['name', 'email', 'phone', 'role', 'status', 'password']);

    $name = textoObrigatorio($input, 'name', 100, 'nome');
    $email = textoObrigatorio($input, 'email', 100, 'e-mail');
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        throw new ApiException(400, 'Informe um endereço de e-mail válido.');
    }

    $role = validarEnum($input['role'] ?? 'tecnico', ['admin', 'supervisor', 'tecnico'], 'perfil do usuário');
    $status = validarEnum($input['status'] ?? 'ativo', ['ativo', 'inativo'], 'status do usuário');
    $permissionName = ['admin' => 'Administrador', 'supervisor' => 'Supervisor', 'tecnico' => 'Técnico'][$role];
    $permissionStmt = $pdo->prepare('SELECT id_permissao FROM permissao WHERE nome = ? LIMIT 1');
    $permissionStmt->execute([$permissionName]);
    $permissionId = $permissionStmt->fetchColumn();
    if ($permissionId === false) {
        throw new ApiException(500, 'Não foi possível determinar a permissão do usuário.');
    }

    $data = [
        'nome' => $name,
        'email' => $email,
        'telefone' => textoOpcional($input, 'phone', 20, 'telefone'),
        'role' => $role,
        'status' => $status,
        'id_permissao' => (int) $permissionId,
    ];

    $password = $input['password'] ?? null;
    if ($isCreate || ($password !== null && $password !== '')) {
        if (!is_string($password) || strlen($password) < 8 || strlen($password) > 72) {
            throw new ApiException(400, 'A senha deve ter entre 8 e 72 bytes.');
        }
        $data['senha'] = password_hash($password, PASSWORD_DEFAULT);
    }
    return $data;
}

function validarId(mixed $value, string $label): int
{
    if ((!is_string($value) && !is_int($value)) || !ctype_digit((string) $value) || (int) $value < 1) {
        throw new ApiException(400, 'Selecione um registro válido para ' . $label . '.');
    }
    return (int) $value;
}

function validateSensorIds(mixed $sensorIds): array
{
    if (!is_array($sensorIds) || count($sensorIds) > 500 || !array_is_list($sensorIds)) {
        throw new ApiException(400, 'A lista de sensores vinculados é inválida.');
    }
    $ids = [];
    foreach ($sensorIds as $sensorId) {
        $id = validarId($sensorId, 'sensor');
        if (in_array($id, $ids, true)) {
            throw new ApiException(400, 'A lista contém sensores duplicados.');
        }
        $ids[] = $id;
    }
    return $ids;
}

function syncMachineSensors(PDO $pdo, int $machineId, int $corporationId, array $sensorIds): void
{
    if ($sensorIds !== []) {
        $placeholders = implode(',', array_fill(0, count($sensorIds), '?'));
        $check = $pdo->prepare(
            'SELECT COUNT(*) FROM sensor
             WHERE id_corporacao = ?
               AND (id_maquina IS NULL OR id_maquina = ?)
               AND id_sensor IN (' . $placeholders . ')'
        );
        $check->execute(array_merge([$corporationId, $machineId], $sensorIds));
        if ((int) $check->fetchColumn() !== count($sensorIds)) {
            throw new ApiException(409, 'Um ou mais sensores não estão disponíveis para vinculação.');
        }
    }

    $clear = $pdo->prepare('UPDATE sensor SET id_maquina = NULL WHERE id_maquina = ? AND id_corporacao = ?');
    $clear->execute([$machineId, $corporationId]);

    if ($sensorIds === []) {
        return;
    }

    $placeholders = implode(',', array_fill(0, count($sensorIds), '?'));
    $update = $pdo->prepare(
        'UPDATE sensor SET id_maquina = ? WHERE id_corporacao = ? AND id_sensor IN (' . $placeholders . ')'
    );
    $update->execute(array_merge([$machineId, $corporationId], $sensorIds));
}

function mapToJs(string $entity, array $row, PDO $pdo, int $corporationId, bool $isAdmin): array
{
    $idFields = [
        'corporations' => 'id_corporacao',
        'users' => 'id_usuario',
        'machines' => 'id_maquina',
        'sensors' => 'id_sensor',
        'orders' => 'id_os',
    ];
    $out = ['id' => (string) $row[$idFields[$entity]]];

    if ($entity === 'corporations') {
        return $out + [
            'name' => (string) $row['nome'],
            'cnpj' => (string) $row['cnpj'],
            'email' => (string) $row['email'],
        ];
    }

    if ($entity === 'users') {
        $out += [
            'name' => (string) $row['nome'],
            'role' => (string) $row['role'],
            'status' => (string) $row['status'],
            'createdAt' => (string) $row['data_criacao'],
        ];
        if ($isAdmin) {
            $out['email'] = (string) $row['email'];
            $out['phone'] = (string) ($row['telefone'] ?? '');
        }
        return $out;
    }

    if ($entity === 'machines') {
        $out += [
            'name' => (string) $row['nome'],
            'model' => (string) ($row['modelo'] ?? ''),
            'manufacturer' => (string) ($row['fabricante'] ?? ''),
            'location' => (string) ($row['localizacao'] ?? ''),
            'department' => (string) ($row['departamento'] ?? ''),
            'status' => (string) $row['status'],
            'installDate' => (string) ($row['data_instalacao'] ?? ''),
            'lastMaintenance' => (string) ($row['ultima_manutencao'] ?? ''),
            'nextMaintenance' => (string) ($row['proxima_manutencao'] ?? ''),
        ];
        $stmt = $pdo->prepare('SELECT id_sensor FROM sensor WHERE id_maquina = ? AND id_corporacao = ? ORDER BY id_sensor');
        $stmt->execute([(int) $row['id_maquina'], $corporationId]);
        $out['sensorIds'] = array_map(static fn(array $item): string => (string) $item['id_sensor'], $stmt->fetchAll());
        return $out;
    }

    if ($entity === 'sensors') {
        return $out + [
            'name' => (string) $row['nome'],
            'type' => (string) $row['tipo'],
            'unit' => (string) ($row['unidade'] ?? ''),
            'location' => (string) ($row['localizacao'] ?? ''),
            'minThreshold' => (float) $row['min_limite'],
            'maxThreshold' => (float) $row['max_limite'],
            'currentValue' => (float) $row['valor_atual'],
            'status' => (string) $row['status'],
            'lastReadingAt' => (string) ($row['ultima_leitura'] ?? ''),
            'machineId' => $row['id_maquina'] === null ? null : (string) $row['id_maquina'],
        ];
    }

    if ($entity === 'orders') {
        return $out + [
            'title' => (string) $row['titulo'],
            'description' => (string) ($row['descricao'] ?? ''),
            'type' => (string) $row['tipo'],
            'priority' => (string) $row['prioridade'],
            'status' => (string) $row['status'],
            'estimatedHours' => (float) $row['horas_estimadas'],
            'scheduledFor' => (string) ($row['data_prevista'] ?? ''),
            'createdAt' => (string) $row['data_abertura'],
            'completedAt' => (string) ($row['data_encerramento'] ?? ''),
            'machineId' => (string) $row['id_maquina'],
            'assignedToId' => (string) $row['id_usuario'],
        ];
    }

    return $out;
}
