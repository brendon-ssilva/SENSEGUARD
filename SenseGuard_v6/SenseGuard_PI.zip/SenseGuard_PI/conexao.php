<?php
declare(strict_types=1);

/**
 * Conexão centralizada do SenseGuard.
 * Em desenvolvimento local, copie config.local.php.example para config.local.php.
 * O arquivo config.local.php deve permanecer fora do Git.
 */

$configFile = __DIR__ . '/config.local.php';

if (!is_file($configFile) || !is_readable($configFile)) {
    error_log('SenseGuard: arquivo config.local.php ausente ou sem permissão de leitura.');
    throw new RuntimeException('Configuração local do banco indisponível.');
}

$config = require $configFile;

if (
    !is_array($config)
    || !isset($config['host'], $config['name'], $config['user'], $config['pass'])
    || !is_string($config['host'])
    || !is_string($config['name'])
    || !is_string($config['user'])
    || !is_string($config['pass'])
    || $config['host'] === ''
    || $config['name'] === ''
    || $config['user'] === ''
) {
    error_log('SenseGuard: configuração local do banco inválida.');
    throw new RuntimeException('Configuração local do banco inválida.');
}

$dsn = sprintf(
    'mysql:host=%s;dbname=%s;charset=utf8mb4',
    $config['host'],
    $config['name']
);

try {
    $pdo = new PDO($dsn, $config['user'], $config['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_STRINGIFY_FETCHES  => false,
    ]);
} catch (PDOException $e) {
    error_log('SenseGuard: falha ao estabelecer conexão PDO: ' . $e->getMessage());
    throw $e;
}
