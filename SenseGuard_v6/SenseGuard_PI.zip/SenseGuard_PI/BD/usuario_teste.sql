-- ================================================================
-- Usuário de teste do SenseGuard
-- Execute APÓS schema.sql.
-- Login: admin.teste@senseguard.local
-- Senha: SenseGuard@123
-- ================================================================

USE senseguard;

INSERT INTO usuario
  (nome, cpf, email, senha, telefone, role, status, id_permissao, id_corporacao)
SELECT
  'Administrador de Teste',
  NULL,
  'admin.teste@senseguard.local',
  '$2y$12$FW0S.cQJWIYa.fixYV54T.KsNw2zLeDPX7at7IhNyZjfdl6hZMaOu',
  NULL,
  'admin',
  'ativo',
  p.id_permissao,
  c.id_corporacao
FROM permissao AS p
INNER JOIN corporacao AS c ON c.id_corporacao = 1
WHERE p.nome = 'Administrador'
  AND NOT EXISTS (
    SELECT 1
    FROM usuario AS u
    WHERE u.email = 'admin.teste@senseguard.local'
  );
