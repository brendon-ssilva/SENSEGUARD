<?php
declare(strict_types=1);

/** Configuração LOCAL para XAMPP. Não publicar no Git nem usar em produção. */
return [
    'host' => '127.0.0.1',
    'name' => 'senseguard',
    'user' => 'root',
    'pass' => '',
];
