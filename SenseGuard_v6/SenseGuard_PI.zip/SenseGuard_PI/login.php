<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

function responderLogin(int $status, array $payload): never
{
    http_response_code($status);
    try {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        http_response_code(500);
        echo '{"success":false,"message":"Ocorreu um erro interno."}';
    }
    exit;
}

try {
    require_once __DIR__ . '/conexao.php';
    require_once __DIR__ . '/protect.php';
} catch (Throwable $e) {
    error_log('SenseGuard login: não foi possível carregar a conexão: ' . $e->getMessage());
    responderLogin(500, ['success' => false, 'message' => 'Não foi possível processar o login no momento.']);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    responderLogin(405, ['success' => false, 'message' => 'Método não permitido.']);
}

$contentType = strtolower(trim(explode(';', (string) ($_SERVER['CONTENT_TYPE'] ?? ''))[0]));
if ($contentType !== 'application/json') {
    responderLogin(415, ['success' => false, 'message' => 'Tipo de conteúdo não suportado.']);
}

$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($contentLength > 16384) {
    responderLogin(413, ['success' => false, 'message' => 'Requisição muito grande.']);
}

$rawInput = file_get_contents('php://input');
try {
    $input = json_decode($rawInput === false ? '' : $rawInput, true, 32, JSON_THROW_ON_ERROR);
} catch (JsonException $e) {
    responderLogin(400, ['success' => false, 'message' => 'Dados de acesso inválidos.']);
}

if (!is_array($input) || array_is_list($input)) {
    responderLogin(400, ['success' => false, 'message' => 'Formato de requisição inválido.']);
}

$email = $input['email'] ?? null;
$password = $input['password'] ?? null;
if (!is_string($email) || !is_string($password)) {
    responderLogin(400, ['success' => false, 'message' => 'Informe um e-mail e uma senha válidos.']);
}

$email = trim($email);
if (
    $email === ''
    || strlen($email) > 254
    || filter_var($email, FILTER_VALIDATE_EMAIL) === false
    || $password === ''
    || strlen($password) > 72
) {
    responderLogin(400, ['success' => false, 'message' => 'Informe um e-mail e uma senha válidos.']);
}

try {
    iniciarSessaoSegura();

    $now = time();
    $attemptWindow = 900;
    $maxAttempts = 10;

    if (!isset($_SESSION['login_attempts']) || !is_array($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = ['count' => 0, 'started_at' => $now];
    }
    if (($now - (int) ($_SESSION['login_attempts']['started_at'] ?? 0)) > $attemptWindow) {
        $_SESSION['login_attempts'] = ['count' => 0, 'started_at' => $now];
    }
    if ((int) ($_SESSION['login_attempts']['count'] ?? 0) >= $maxAttempts) {
        header('Retry-After: 900');
        responderLogin(429, ['success' => false, 'message' => 'Muitas tentativas. Aguarde antes de tentar novamente.']);
    }

    $stmt = $pdo->prepare(
        'SELECT id_usuario, nome, email, senha, role, status, id_permissao, id_corporacao
         FROM usuario
         WHERE email = ?
         LIMIT 1'
    );
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    $contaAtiva = is_array($usuario) && ($usuario['status'] ?? '') === 'ativo';
    $hashValido = is_array($usuario)
        && isset($usuario['senha'])
        && is_string($usuario['senha'])
        && password_verify($password, $usuario['senha']);

    if (!$contaAtiva || !$hashValido) {
        $_SESSION['login_attempts']['count'] = (int) ($_SESSION['login_attempts']['count'] ?? 0) + 1;
        responderLogin(401, ['success' => false, 'message' => 'E-mail ou senha incorretos.']);
    }

    $role = strtolower(trim((string) $usuario['role']));
    if (!in_array($role, ['admin', 'supervisor', 'tecnico'], true)) {
        error_log('SenseGuard login: usuário com perfil inválido. ID=' . (string) $usuario['id_usuario']);
        responderLogin(403, ['success' => false, 'message' => 'A conta não possui um perfil autorizado.']);
    }

    if (!session_regenerate_id(true)) {
        error_log('SenseGuard login: falha ao regenerar o identificador da sessão.');
        responderLogin(500, ['success' => false, 'message' => 'Não foi possível processar o login no momento.']);
    }

    $_SESSION['user_id'] = (string) $usuario['id_usuario'];
    $_SESSION['user_name'] = (string) $usuario['nome'];
    $_SESSION['user_email'] = (string) $usuario['email'];
    $_SESSION['user_role'] = $role;
    $_SESSION['permission_id'] = (string) $usuario['id_permissao'];
    $_SESSION['corporation_id'] = (string) $usuario['id_corporacao'];
    $_SESSION['authenticated_at'] = $now;
    $_SESSION['last_activity'] = $now;
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    unset($_SESSION['login_attempts']);

    if (password_needs_rehash((string) $usuario['senha'], PASSWORD_DEFAULT)) {
        $novoHash = password_hash($password, PASSWORD_DEFAULT);
        $update = $pdo->prepare('UPDATE usuario SET senha = ? WHERE id_usuario = ?');
        $update->execute([$novoHash, (int) $usuario['id_usuario']]);
    }

    responderLogin(200, [
        'success' => true,
        'message' => 'Login realizado com sucesso.',
        'redirect' => 'dashboard.php',
        'user' => [
            'id' => (string) $usuario['id_usuario'],
            'nome' => (string) $usuario['nome'],
            'email' => (string) $usuario['email'],
            'role' => $_SESSION['user_role'],
        ],
    ]);
} catch (PDOException $e) {
    error_log('SenseGuard login: falha PDO: ' . $e->getMessage());
    responderLogin(500, ['success' => false, 'message' => 'Não foi possível processar o login no momento.']);
} catch (Throwable $e) {
    error_log('SenseGuard login: erro inesperado: ' . $e->getMessage());
    responderLogin(500, ['success' => false, 'message' => 'Não foi possível processar o login no momento.']);
}
