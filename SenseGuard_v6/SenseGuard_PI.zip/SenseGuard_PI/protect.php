<?php
declare(strict_types=1);

function iniciarSessaoSegura(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', '7200');

    session_name('SENSEGUARDSESSID');

    $https = isset($_SERVER['HTTPS'])
        && $_SERVER['HTTPS'] !== ''
        && strtolower((string) $_SERVER['HTTPS']) !== 'off';

    $basePath = str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/')));
    $cookiePath = rtrim($basePath, '/');
    if ($cookiePath === '') {
        $cookiePath = '/';
    }

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => $cookiePath,
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    if (!session_start()) {
        throw new RuntimeException('Não foi possível iniciar a sessão.');
    }
}

function destruirSessaoSegura(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $params['path'] ?: '/',
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ]);
    }

    session_destroy();
}

function obterUsuarioAutenticado(PDO $pdo): ?array
{
    iniciarSessaoSegura();

    $sessionId = $_SESSION['user_id'] ?? null;
    if (!is_string($sessionId) || !ctype_digit($sessionId) || (int) $sessionId < 1) {
        return null;
    }

    $lastActivity = (int) ($_SESSION['last_activity'] ?? $_SESSION['authenticated_at'] ?? time());
    if (time() - $lastActivity > 7200) {
        destruirSessaoSegura();
        return null;
    }

    $stmt = $pdo->prepare(
        'SELECT id_usuario, nome, email, role, status, id_permissao, id_corporacao
         FROM usuario
         WHERE id_usuario = ?
         LIMIT 1'
    );
    $stmt->execute([(int) $sessionId]);
    $usuario = $stmt->fetch();

    if (!is_array($usuario) || ($usuario['status'] ?? '') !== 'ativo') {
        destruirSessaoSegura();
        return null;
    }

    $_SESSION['user_role'] = strtolower(trim((string) $usuario['role']));
    $_SESSION['corporation_id'] = (string) $usuario['id_corporacao'];
    $_SESSION['last_activity'] = time();

    return $usuario;
}

function protegerPagina(PDO $pdo): array
{
    $usuario = obterUsuarioAutenticado($pdo);
    if ($usuario === null) {
        header('Location: index.html');
        exit;
    }

    if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $usuario;
}
