<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

try {
    require_once __DIR__ . '/conexao.php';
    require_once __DIR__ . '/protect.php';
    $usuarioAtual = protegerPagina($pdo);
} catch (PDOException $e) {
    error_log('SenseGuard dashboard: falha PDO ao validar a página: ' . $e->getMessage());
    http_response_code(500);
    exit('Não foi possível carregar o sistema no momento. Tente novamente mais tarde.');
} catch (Throwable $e) {
    error_log('SenseGuard dashboard: erro ao carregar a página: ' . $e->getMessage());
    http_response_code(500);
    exit('Não foi possível carregar o sistema no momento. Tente novamente mais tarde.');
}

$csrfToken = htmlspecialchars((string) $_SESSION['csrf_token'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?>
<!doctype html>
<html lang="pt-BR">
  <head>
    <meta name="csrf-token" content="<?= $csrfToken ?>" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SenseGuard | Dashboard Industrial</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=JetBrains+Mono:wght@400;500;600&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="dashboard.css?v=20261030-settings" />
  </head>
  <body>
    <div id="application_wrapper" class="app-wrapper">
      <aside id="sidebar_container" class="sidebar-container">
        <header class="brand-header">
          <div class="brand-icon">
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#fff"
              stroke-width="2.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
          </div>
          <div class="brand-text-container">
            <span class="brand-name">SenseGuard</span>
            <span class="brand-version">Industrial v2.1</span>
          </div>
        </header>

        <nav id="navigation_menu" class="navigation-menu"></nav>

        <div class="sidebar-footer">
          <button type="button" class="nav-button w-full" id="settings_nav_button" onclick="app.navigate('settings')">
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <circle cx="12" cy="12" r="3" />
              <path
                d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"
              />
            </svg>
            Configurações
          </button>
        </div>

        <div class="user-profile-badge">
          <div
            class="user-avatar"
            style="background: var(--violet-dim); color: var(--violet)"
          >
            CM
          </div>
          <div class="user-details">
            <span class="user-name">Usuário</span>
            <span class="user-role">Carregando perfil...</span>
          </div>
          <button type="button" class="profile-logout-button" id="profile_logout_button" aria-label="Sair da conta" title="Sair da conta">
            <span aria-hidden="true">↪</span> Sair
          </button>
        </div>
      </aside>

      <div id="main_content_area" class="main-content-area">
        <header id="topbar_header" class="topbar-header"></header>
        <main id="view_container" class="view-container"></main>
      </div>
    </div>

    <div id="modal_overlay" class="modal-overlay">
      <section id="modal_panel" class="modal-panel">
        <header id="modal_header" class="modal-header">
          <h3 id="modal_title" class="modal-title"></h3>
          <button class="modal-close-button" onclick="app.closeModal()">
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </header>
        <div id="modal_body" class="modal-body"></div>
        <footer id="modal_footer" class="modal-footer"></footer>
      </section>
    </div>

    <style>
      .user-profile-badge { gap: 10px; }
      .profile-logout-button { margin-left: auto; border: 1px solid var(--border, #ddd); border-radius: 8px; padding: 7px 10px; background: transparent; color: var(--fg, #333); cursor: pointer; font: inherit; font-size: 12px; white-space: nowrap; }
      .profile-logout-button:hover { background: var(--surface-hover, rgba(127,127,127,.12)); }
      .profile-logout-button:disabled { opacity: .65; cursor: wait; }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="dashboard.js?v=20261030-settings"></script>
    <script src="settings.js?v=20261030-settings"></script>
  </body>
</html>